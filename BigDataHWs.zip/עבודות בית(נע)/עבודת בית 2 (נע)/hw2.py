import string
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, DateTime, func, LargeBinary
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
import datetime
import bcrypt

Base = declarative_base()



class User(Base):
    __tablename__ = "Users"
    username = Column(String, primary_key=True)  # the ID
    password = Column(LargeBinary, nullable=False)
    first_name = Column(String)
    last_name = Column(String)
    date_of_birth = Column(DateTime)
    registration_date = Column(DateTime)

    # one-to-many relationship user can have multiple histories
    history = relationship("History", back_populates="user", cascade="all, delete-orphan")

    def __init__(self, username, password, first_name, last_name, date_of_birth, registration_date):

        self.username = username
        self.set_password(password)
        self.first_name = first_name
        self.last_name = last_name
        self.date_of_birth = date_of_birth
        self.registration_date = registration_date
        self.history = []

    def set_password(self, raw_password):
        # setting the username password by bcrypt library -> hashed  password
        self.password = bcrypt.hashpw(raw_password.encode('utf-8'), bcrypt.gensalt())

    def check_password(self, raw_password):
        # validating the password using the wanted library
        return bcrypt.checkpw(raw_password.encode('utf-8'), self.password)

    def add_history(self, media_item_id):

        # flag for if the existence of media_item_id
        flag = next((i for i in self.history if i.media_item_id == media_item_id), None)

        if flag:
            history = History(user_id=self.username, media_item_id=media_item_id, viewtime=datetime.now())
            self.history.append(history)
        else:
            raise ValueError("check the media item id")

    def sum_title_length(self):

        # wanted value
        total_lenght = 0
        for media_item in self.history:
            total_lenght += len(media_item.title)

        return total_lenght


class MediaItem(Base):
    __tablename__ = "MediaItems"
    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String)
    prod_year = Column(Integer)
    title_length = Column(Integer)

    # multiple history can have one mediaitem many-to-one relationship
    history = relationship("History", back_populates="user", cascade="all, delete-orphan")

    def __init__(self, title, prod_year, title_length):
        self.title = title
        self.prod_year = prod_year
        self.title_length = title_length


class History(Base):
    __tablename__ = "History"

    id = Column(Integer, primary_key=True, autoincrement=True)
    viewtime = Column(DateTime)

    # FK - Foreign Keys
    user_id = Column(String, ForeignKey("Users.username"))
    media_item_id = Column(Integer, ForeignKey("MediaItems.id"))

    # realtioships
    user = relationship("User", back_populates="History")
    mediaitem = relationship("MediaItem", back_populates="History")

    def __init__(self, user_id, media_item_id, viewtime):
        self.user_id = user_id
        self.media_item_id = media_item_id
        self.viewtime = viewtime


class Repository:
    def __init__(self, model_class):
        self.model_class = model_class

    def get_by_id(self, session, entity_id):
        return session.query(self.model_class).filter(self.model_class.id == entity_id).first()

    def get_all(self, session):
        return session.query(self.model_class).all()

    def delete(self, session, entity):
        session.delete(entity)

    def add(self, session, entity):
        session.add(entity)


class UserRepository(Repository):
    def __init__(self):

        super().__init__(User)

    def validateUser(self, session, username: str, password: str) -> bool:

        user_flag = session.query(User).filter(User.username.like(username)).first()

        if user_flag:
            return user_flag.check_password(password)
        else:
            return False

    def getNumberOfRegistredUsers(self, session, n: int) -> int:

        # calucalting the start_date
        start_date = datetime.now() - n
        count = session.query(User).filter(User.registration_date > start_date).count()

        return count


class ItemRepository(Repository):
    def __init__(self):
        super().__init__(MediaItem)

    def getTopNItems(self, session, top_n: int) -> list:
        return session.query(MediaItem).order_by(MediaItem.id).limit(top_n).all()


class UserService:
    def __init__(self, session, user_repo: UserRepository):
        self.user_repo = user_repo
        self.session = session

    def create_user(self, username, password, first_name, last_name, date_of_birth):

        # if the username hasn't been created -> do creation
        if not self.user_repo.validateUser(self.session, username, password):
            new_user = User(username, password, first_name, last_name, date_of_birth, datetime.now())
            self.session.add(new_user)
            self.session.commit()
        else:
            raise ValueError("the username already exists")

    def add_history_to_user(self, username, media_item_id):

        # if the username exists -> activate the user.add_history(media_item) method
        user = self.user_repo.get_by_id(self.session, username)
        if user is not None:
            user.add_history(media_item_id)
            self.session.commit()
        else:
            raise ValueError("the username does not exist")

    def validateUser(self, username: str, password: str) -> bool:
        return self.user_repo.validateUser(self.session, username, password)

    def getNumberOfRegistredUsers(self, n: int) -> int:
        return self.user_repo.getNumberOfRegistredUsers(self.session, n)

    def sum_title_length_to_user(self, username):
        user = self.user_repo.get_by_id(self.session, username)
        if user is not None:
            sum = 0
            for media_item in user.history:
                sum += len(media_item.title)
            return sum
        else:
            raise ValueError("User not found")

    def get_all_users(self):
        return self.user_repo.get_all(self.session)


class ItemService:
    def __init__(self, session, item_repo: ItemRepository):
        self.item_repo = item_repo
        self.session = session

    def create_item(self, title, prod_year):
        new_media_item = MediaItem(title, prod_year, len(title))
        self.session.add(new_media_item)
        self.session.commit()


