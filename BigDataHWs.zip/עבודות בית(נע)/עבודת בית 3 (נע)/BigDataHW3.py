import pymongo
import bcrypt
import ast
import pandas as pd
import random
from pymongo import MongoClient
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class LoginManager:

    def __init__(self) -> None:
        # MongoDB connection
        self.client = pymongo.MongoClient("mongodb://localhost:27017/")
        self.db = self.client["hw3"]
        self.collection = self.db["users"]
        self.salt = b"$2b$12$ezgTynDsK3pzF8SStLuAPO"  # TODO: if not working, generate a new salt

    def register_user(self, username: str, password: str) -> None:

        # instruction num 1
        if not username or not password:
            raise ValueError("Username and password are required.")

        # instruction num 2
        if len(username) < 3 or len(password) < 3:
            raise ValueError("Username and password must be at least 3 characters.")

        # instruction num 3
        if self.collection.find_one({"username": username}) != None:
            raise ValueError(f"User already exists: {username}.")

        # instruction 4
        hashed_pass = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
        self.collection.insert_one({"username": username, "password": hashed_pass})

    def login_user(self, username: str, password: str) -> object:

        # instruction num 2
        user = self.collection.find_one({"username": username})

        # instruction num 1 & 3
        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"]):
            print(f"Logged in successfully as: {username}")
            return user
        # instruction num 4
        else:
            raise ValueError("Invalid username or password")

class DBManager:

    def __init__(self) -> None:
        # MongoDB connection
        self.client = pymongo.MongoClient("mongodb://localhost:27017/")
        self.db = self.client["hw3"]
        self.user_collection = self.db["users"]
        self.game_collection = self.db["games"]

        # a new collection that we will use for avoiding multiple csv data file loading
        self.status_collection = self.db["status"]

        # title index mainly to faster the csv loading method
        self.game_collection.create_index("title", unique=True)

    def is_data_loaded(self) -> bool:
        # Check if the data loading flag is set to True in the status collection
        status_doc = self.status_collection.find_one({"data_loaded": True})
        return bool(status_doc)

    # updating the status to True
    def mark_data_as_loaded(self) -> None:
        # Mark the data as loaded by setting the flag in the status collection
        self.status_collection.update_one({"data_loaded": True},{"$set": {"data_loaded": True}},
            upsert=True  # If no document exists, create one
        )

    def load_csv(self) -> None:
        # if the data has been loaded before
        if self.is_data_loaded():
            return

        else:
            # instruction 1
            df = pd.read_csv("NintendoGames.csv")

            # insrtuction 2
            df["genres"] = df["genres"].apply(ast.literal_eval)

            # insrtuction 3
            df["is_rented"] = False

            # insrtuction 4 & 5
            data_to_insert = df.to_dict("records")
            for record in data_to_insert:
                if not self.game_collection.find_one({"title": record["title"]}):
                    self.game_collection.insert_one(record)
            self.mark_data_as_loaded()

    def rent_game(self, user: dict, game_title: str) -> str:

        # instruction 1
        selected_game = self.game_collection.find_one({"title": game_title})
        # value example:
        # {
        #     "meta_score": 74,
        #     "title": "Mario Kart 8 Deluxe: Booster Course Pass - Wave 5",
        #     "platform": "Switch",
        #     "date": "12-Jul-23",
        #     "user_score": 7.6,
        #     "link": "/game/switch/mario-kart-8-deluxe-booster-course-pass---wave-5",
        #     "esrb_rating": "",
        #     "developers": ["Nintendo"],
        #     "genres": ["Racing", "Arcade", "Automobile"],
        #     "is_rented": False
        # }

        # instruction 2
        if selected_game:
            # Check if the game is not already rented.
            if selected_game["is_rented"] == False:
                self.game_collection.update_one({"title": game_title}, {"$set": {"is_rented": True}})
                self.user_collection.update_one({"_id": user["_id"]}, {"$push": {"rented_games": selected_game["_id"]}})
                return  f"{game_title} rented successfully"

            # instruction 3
            else:
                return f"{game_title} is already rented"
        # instruction 4
        else:
            return f"{game_title} not found"

    def return_game(self, user: dict, game_title: str) -> str:

        # the game with the input title
        selected_game = self.game_collection.find_one({"title": game_title})

        # instruction 1 & 2
        if selected_game["_id"] in user.get("rented_games", []):
            # • Remove the game id from the user's rented games ids list.
            self.user_collection.update_one({"_id": user["_id"]}, {"$pull": {"rented_games": selected_game["_id"]}})

            # • Mark the game as not rented in the game collection.
            self.game_collection.update_one({"_id": selected_game["_id"]}, {"$set": {"is_rented": False}})

            # • Return "{game_title} returned successfully".
            return f"{game_title} returned successfully"

        # instruction 3
        else:
            return f"{game_title} was not rented by you"

    def recommend_games_by_genre(self, user: dict) -> list:
        # instruction 1
        rented_games = list(self.game_collection.find({"_id": {"$in": user.get("rented_games", [])}}))

        # instruction 2
        if not rented_games:
            return ["No games rented"]

        # instruction 3
        genre_counts = {}
        for game in rented_games:
            for genre in game.get("genres", []):
                genre_counts[genre] = genre_counts.get(genre, 0) + 1

        # Choose a genre based on the wanted probability in the question
        genres = list(genre_counts.keys())
        weights = list(genre_counts.values())
        chosen_genre = random.choices(genres, weights=weights, k=1)[0]

        # instruction 4
        recommended_games = list(self.game_collection.aggregate([
            {"$match": {"genres": chosen_genre, "_id": {"$nin": user.get("rented_games", [])}}},
            {"$sample": {"size": 5}}
        ]))

        # instruction 5
        return [game["title"] for game in recommended_games]

    def recommend_games_by_name(self, user: dict) -> list:

        # Instruction 1
        rented_games = list(self.game_collection.find({"_id": {"$in": user.get("rented_games", [])}}))

        # Instruction 2
        if not rented_games:
            return ["No games rented"]

        # Instruction 3: Randomly select one of the rented games to base recommendations on
        # `random.choice(rented_games)` chooses a game randomly from the user's rented games.
        chosen_game = random.choice(rented_games)
        chosen_title = chosen_game["title"]

        # Instruction 4: Retrieve all game titles and IDs from the database
        # so it will helps us in creating the TF-IDF matrix for the comparison.
        all_games = list(self.game_collection.find({}, {"title": 1, "_id": 1}))
        all_titles = [game["title"] for game in all_games]  # Extract just the titles

        # TfidfVectorizer for creating the TF-IDF matrix for all games titles
        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform(all_titles)

        # Instruction 5: Compute the similarity between the chosen game's title and all other titles
        # Transform the chosen title into a TF-IDF vector
        chosen_vector = vectorizer.transform([chosen_title])

        # Calculate cosine similarity between the chosen title and all titles
        similarities = cosine_similarity(chosen_vector, tfidf_matrix).flatten()

        # Exclude games already rented by the user so we will not recommend a rented games
        rented_ids = user.get("rented_games", [])
        filtered_indices = [idx for idx, game in enumerate(all_games) if game["_id"] not in rented_ids]

        # Create a list of tuples (index, similarity_score) for non-rented games
        filtered_similarities = [(i, similarities[i]) for i in filtered_indices]

        # Sort games by similarity scores in descending order
        filtered_similarities.sort(key=lambda x: x[1], reverse=True)

        # Instruction 6: Select the top 5 most similar games
        # Get the indikces of the top 5 most similar games
        top_5_indices = [idx for idx, _ in filtered_similarities[:5]]

        # Retrieve the titles of the recommended games based on their indikces
        recommended_titles = [all_titles[i] for i in top_5_indices]
        return recommended_titles

    def find_top_rated_games(self, min_score) -> list:
        # instruction 1
        selected_games = self.game_collection.find({"user_score": {"$gte": min_score}}, {"title": 1, "user_score": 1, "_id": 0})
        # instruction 2
        return list(selected_games)

    def decrement_scores(self, platform_name) -> None:
        # instrucrion 1 & 2
        self.game_collection.update_many({"platform": platform_name},{"$inc": {"user_score": -1}})

    def get_average_score_per_platform(self) -> dict:
        # Instruction 1
        pipeline = [
            # Instruction 2 & 3
            {"$group": {"_id": "$platform", "average_score": {"$avg": "$user_score"}}}]
        # Execute the aggregation pipeline on the collection
        result = list(self.game_collection.aggregate(pipeline))

        # Instruction 4
        return {item["_id"]: round(item["average_score"], 3) for item in result}

    def get_genres_distribution(self) -> dict:
        # Instruction 1
        pipeline = [
            # Instruction 2
            {"$unwind": "$genres"},
            # Instruction 3 & 4
            {"$group": {"_id": "$genres", "count": {"$sum": 1}}}]
        # Execute the aggregation pipeline on the collection
        result = list(self.game_collection.aggregate(pipeline))

        # Instruction 5
        return {item["_id"]: item["count"] for item in result}

db_manager = DBManager()
db_manager.load_csv()