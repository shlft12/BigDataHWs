import pyodbc
import csv

class DatabaseManager:
    def __init__(self, driver: str, server: str, username: str, password: str, database: str):
        self.connection_string = (
            f"DRIVER={{{ODBC Driver 18 for SQL Server}}};"
            f"SERVER={server};"
            f"UID={username};"
            f"PWD={password};"
            f"DATABASE={database}"
        )
        self.connection = pyodbc.connect(self.connection_string)
        self.cursor = self.connection.cursor()

    def file_to_database(self, path: str) -> None:
        try:
            with open(path, 'r', encoding='utf-8') as file:
                reader = csv.reader(file)
                for row in reader:
                    if len(row) == 2:
                        title, production_year = row
                        self.cursor.execute(
                            """
                            INSERT INTO MediaItems (TITLE, ProductionYear)
                            VALUES (?, ?)
                            """,
                            title, production_year
                        )
            self.connection.commit()
            print("File content inserted successfully into the database.")
        except Exception as e:
            print(f"An error occurred: {e}")

    def calculate_similarity(self) -> None:
        try:
            self.cursor.execute(
                """
                SELECT MID FROM MediaItems
                """
            )
            mids = [row[0] for row in self.cursor.fetchall()]

            for i in range(len(mids)):
                for j in range(i + 1, len(mids)):
                    mid1, mid2 = mids[i], mids[j]
                    self.cursor.execute(
                        """
                        SELECT dbo.SimCalculation(?, ?) AS Similarity
                        """,
                        mid1, mid2
                    )
                    similarity = self.cursor.fetchone()[0]

                    self.cursor.execute(
                        """
                        INSERT INTO Similarity (MID1, MID2, SIMILARITY)
                        VALUES (?, ?, ?)
                        """,
                        mid1, mid2, similarity
                    )
            self.connection.commit()
            print("Similarity calculated and inserted successfully.")
        except Exception as e:
            print(f"An error occurred: {e}")

    def print_similar_items(self, mid: int) -> None:
        try:
            self.cursor.execute(
                """
                SELECT M2.TITLE, S.SIMILARITY
                FROM Similarity S
                JOIN MediaItems M2 ON S.MID2 = M2.MID
                WHERE S.MID1 = ? AND S.SIMILARITY >= 0.25
                ORDER BY S.SIMILARITY ASC
                """,
                mid
            )
            rows = self.cursor.fetchall()
            for row in rows:
                print(f"Title: {row[0]}, Similarity: {rosw[1]:.2f}")
        except Exception as e:
            print(f"An error occurred: {e}")

    def add_summary_items(self) -> None:
        try:
            self.cursor.execute("EXEC AddSummaryItems")
            self.connection.commit()
            print("Summary items added successfully.")
        except Exception as e:
            print(f"An error occurred: {e}")

# Example Usage (Replace with your actual database details):
# db_manager = DatabaseManager(driver="SQL Server", server="localhost", username="sa", password="password", database="MediaDB")
# db_manager.file_to_database("C:\\path\\to\\films.csv")
# db_manager.calculate_similarity()
# db_manager.print_similar_items(1)
# db_manager.add_summary_items()
